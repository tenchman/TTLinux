/* 
 * libdefs.h
 * Copyright (C) 2002, AVM GmbH. All rights reserved.
 * 
 * This Software is  free software. You can redistribute and/or
 * modify such free software under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * The free software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this Software; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA, or see
 * http://www.opensource.org/licenses/lgpl-license.html
 * 
 * Contact: AVM GmbH, Alt-Moabit 95, 10559 Berlin, Germany, email: info@avm.de
 */

#ifndef __have_libdefs_h__
#define __have_libdefs_h__

#include <linux/time.h>
#include <stdarg.h>
#include "common.h"

typedef void (* register_t) (void *, unsigned);
typedef void (* release_t) (void *);
typedef void (* down_t) (void);

typedef enum {

	timer_end	= 0,
	timer_restart	= 1,
	timer_renew	= 2
} restart_t;

typedef restart_t (* timerfunc_t) (unsigned long);

typedef struct __data {

	unsigned	num;
	char *		buffer;
} appldata_t;

typedef struct __lib {

	void (* init) (unsigned, register_t, release_t, down_t);
	char * (* params) (void);
	int (* get_message) (unsigned char *);
	void (* put_message) (unsigned char *);
	unsigned char * (* get_data_block) (unsigned, unsigned long, unsigned);
	void (* free_data_block) (unsigned, unsigned char *);
	int (* new_ncci) (unsigned, unsigned long, unsigned, unsigned);
	void (* free_ncci) (unsigned, unsigned long);
	unsigned (* block_size) (unsigned);
	unsigned (* window_size) (unsigned);
	unsigned (* card) (void);
	void * (* appl_data) (unsigned);
	unsigned (* appl_attr) (unsigned);
	appldata_t * (* appl_1st_data) (appldata_t *);
	appldata_t * (* appl_next_data) (appldata_t *);
	void * (* malloc) (unsigned);
	void (* free) (void *);
	void * (* malloc2) (unsigned);
	void (* delay) (unsigned);
	unsigned long (* msec) (void);
	unsigned long long (* msec64) (void);
	int (* timer_new) (unsigned);
	void (* timer_delete) (void);
	int (* timer_start) (unsigned, unsigned long, unsigned long, timerfunc_t);
	int (* timer_stop) (unsigned);
	void (* timer_poll) (void);
	int (* get_time) (struct timeval *);
	void (* printf) (const char *, va_list);
	void (* putf) (char *, va_list);
	void (* puts) (char *);
	void (* putl) (long);
	void (* puti) (int);
	void (* putc) (char);
	void (* putnl) (void);
	void (* _enter_critical) (const char *, int);
	void (* _leave_critical) (const char *, int);
	void (* enter_critical) (void);
	void (* leave_critical) (void);
	void (* enter_cache_sensitive_code) (void);
	void (* leave_cache_sensitive_code) (void);

	void (* xfer_req) (dif_require_p, unsigned);

	char *		name;
	unsigned	udata;
	void *		pdata;
} lib_interface_t, * lib_interface_p;

typedef struct __f {
	
	unsigned	nfuncs;
	void	     (* sched_ctrl) (unsigned);
	void         (* wakeup_ctrl) (unsigned);
	void         (* version_ind) (char *);
	unsigned     (* sched_suspend) (unsigned long);
	unsigned     (* sched_resume) (void);
	unsigned     (* ctrl_remove) (void);
	unsigned     (* ctrl_add) (void);
} functions_t, * functions_p;

typedef struct __cb {

	unsigned (* cm_start) (void);
	char * (* cm_init) (unsigned, unsigned);
	int (* cm_activate) (void);
	int (* cm_exit) (void);
	unsigned (* cm_handle_events) (void);
	int (* cm_schedule) (void);
	void (* cm_timer_irq_control) (unsigned);
	void (* cm_register_ca_functions) (functions_p);

	int (* cc_need_debug_buffer) (void);
	void (* cc_init_debug) (void *, unsigned);
	void (* cc_init_dma) (dma_list_t, unsigned, dma_list_t, unsigned);
	unsigned (* cc_num_link_buffer) (int);
	unsigned (* cc_link_version) (void);
	unsigned (* cc_timer_offset) (void);
	unsigned (* cc_pc_ack_offset) (void);
	unsigned (* cc_buffer_params) (unsigned *, ioaddr_p *, unsigned *, unsigned *);
	void (* cc_compress_code) (void);
	int (* cc_status) (unsigned, void *, void *);
	int (* cc_run) (void);
} lib_callback_t, * lib_callback_p;

#endif

